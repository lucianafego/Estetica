# @floating-ui/dom

## 0.1.7

### Patch Changes

- fix: transformed body (#1427)
- fix(types): strict DOM types (#1432)
- fix: scaled parent (#1435, #1436)
- fix: CJS build
- perf: save some bytes and execution
- Updated dependencies
  - @floating-ui/core@0.2.1

## 0.1.6

### Patch Changes

- test
- Updated dependencies
  - @floating-ui/core@0.2.0

## 0.1.5

### Patch Changes

- Updated dependencies
  - @floating-ui/core@0.1.5

## 0.1.4

### Patch Changes

- fix(core): limitShift type
- Updated dependencies
  - @floating-ui/core@0.1.4

## 0.1.3

### Patch Changes

- chore: upgrade @floating-ui/core to @0.1.3
