export default {
  presets: [['@babel/env', {loose: true}], '@babel/typescript', '@babel/react'],
};
